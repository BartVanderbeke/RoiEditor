import os
import sys

def main():
    from RoiEditor.GuiLauncher import launch
    launch()

if __name__ == "__main__":
    main()